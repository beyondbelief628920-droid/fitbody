"use client";

import Link from "next/link";
import {
  Brain,
  Phone,
  Mail,
  MapPin,
  Clock,
  Heart,
  ArrowUp,
} from "lucide-react";
import { SITE_CONFIG, NAV_LINKS, WORKING_HOURS } from "@/lib/constants";

/**
 * Site footer with navigation, contact information, working hours,
 * and scroll-to-top functionality.
 */
export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary-950 text-white" role="contentinfo">
      {/* Decorative top border */}
      <div className="h-1 bg-gradient-to-r from-primary-500 via-accent-500 to-warm-500" />

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 sm:py-16 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {/* Brand Column */}
          <div className="sm:col-span-2 lg:col-span-1">
            <Link href="/" className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-600 text-white">
                <Brain className="h-5 w-5" aria-hidden="true" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-white">
                  Alemi Hospital
                </span>
                <span className="text-[10px] font-medium uppercase tracking-widest text-primary-300">
                  Neuropsychiatric
                </span>
              </div>
            </Link>
            <p className="mt-4 text-sm leading-relaxed text-primary-200/80">
              Afghanistan&apos;s first private neuropsychiatric hospital,
              providing compassionate mental health care since 2004 in
              Mazar-i-Sharif. Healing minds, restoring hope.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-primary-300">
              Quick Links
            </h3>
            <ul className="space-y-2.5">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-primary-200/80 transition-colors hover:text-white"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-primary-300">
              Contact Us
            </h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <MapPin
                  className="mt-0.5 h-4 w-4 shrink-0 text-accent-400"
                  aria-hidden="true"
                />
                <span className="text-sm text-primary-200/80">
                  {SITE_CONFIG.address}
                </span>
              </li>
              <li>
                <a
                  href={`tel:${SITE_CONFIG.phone.replace(/\s/g, "")}`}
                  className="flex items-center gap-2.5 text-sm text-primary-200/80 transition-colors hover:text-white"
                >
                  <Phone
                    className="h-4 w-4 shrink-0 text-accent-400"
                    aria-hidden="true"
                  />
                  {SITE_CONFIG.phone}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${SITE_CONFIG.email}`}
                  className="flex items-center gap-2.5 text-sm text-primary-200/80 transition-colors hover:text-white"
                >
                  <Mail
                    className="h-4 w-4 shrink-0 text-accent-400"
                    aria-hidden="true"
                  />
                  {SITE_CONFIG.email}
                </a>
              </li>
            </ul>
          </div>

          {/* Working Hours */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-primary-300">
              Working Hours
            </h3>
            <ul className="space-y-3">
              {WORKING_HOURS.map((schedule) => (
                <li key={schedule.day} className="flex items-start gap-2.5">
                  <Clock
                    className="mt-0.5 h-4 w-4 shrink-0 text-accent-400"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="text-sm font-medium text-primary-100">
                      {schedule.day}
                    </p>
                    <p className="text-xs text-primary-300/80">
                      {schedule.hours}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-primary-800/50 pt-8 sm:flex-row">
          <p className="flex items-center gap-1 text-xs text-primary-400">
            © {currentYear} {SITE_CONFIG.name}. All rights reserved. Made with
            <Heart
              className="inline h-3 w-3 fill-red-400 text-red-400"
              aria-hidden="true"
            />
            for mental health.
          </p>

          <button
            type="button"
            className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs text-primary-400 transition-colors hover:bg-primary-900 hover:text-white"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            aria-label="Scroll to top of page"
          >
            <ArrowUp className="h-3 w-3" aria-hidden="true" />
            Back to top
          </button>
        </div>
      </div>
    </footer>
  );
}
