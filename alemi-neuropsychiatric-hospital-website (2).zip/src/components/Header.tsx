"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, Phone, Brain } from "lucide-react";
import { NAV_LINKS, SITE_CONFIG } from "@/lib/constants";

/**
 * Responsive header with mobile navigation, scroll-aware styling,
 * and accessible keyboard navigation.
 */
export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const pathname = usePathname();

  const handleScroll = useCallback(() => {
    setIsScrolled(window.scrollY > 20);
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  // Close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [pathname]);

  // Lock body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isMobileMenuOpen]);

  const isActiveLink = (href: string) => {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-white/95 backdrop-blur-md shadow-lg shadow-slate-900/5"
          : "bg-transparent"
      }`}
      role="banner"
    >
      <nav
        className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8"
        aria-label="Main navigation"
      >
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-2.5 group"
          aria-label={`${SITE_CONFIG.name} — Home`}
        >
          <div
            className={`flex h-10 w-10 items-center justify-center rounded-xl transition-colors duration-300 ${
              isScrolled
                ? "bg-primary-600 text-white"
                : "bg-white/15 text-white backdrop-blur-sm"
            }`}
          >
            <Brain className="h-5 w-5" aria-hidden="true" />
          </div>
          <div className="flex flex-col">
            <span
              className={`text-lg font-bold leading-tight transition-colors duration-300 ${
                isScrolled ? "text-primary-900" : "text-white"
              }`}
            >
              Alemi Hospital
            </span>
            <span
              className={`hidden text-[10px] font-medium uppercase tracking-widest transition-colors duration-300 sm:block ${
                isScrolled ? "text-primary-600" : "text-primary-200"
              }`}
            >
              Neuropsychiatric
            </span>
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`relative rounded-lg px-4 py-2 text-sm font-medium transition-all duration-200 ${
                isActiveLink(link.href)
                  ? isScrolled
                    ? "text-primary-700 bg-primary-50"
                    : "text-white bg-white/15"
                  : isScrolled
                    ? "text-slate-600 hover:text-primary-700 hover:bg-primary-50/50"
                    : "text-white/80 hover:text-white hover:bg-white/10"
              }`}
              aria-current={isActiveLink(link.href) ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* CTA + Mobile Toggle */}
        <div className="flex items-center gap-3">
          <a
            href={`tel:${SITE_CONFIG.phone.replace(/\s/g, "")}`}
            className={`hidden items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-200 sm:flex ${
              isScrolled
                ? "bg-primary-600 text-white hover:bg-primary-700 shadow-md shadow-primary-600/25"
                : "bg-white/15 text-white hover:bg-white/25 backdrop-blur-sm"
            }`}
            aria-label="Call the hospital"
          >
            <Phone className="h-4 w-4" aria-hidden="true" />
            Emergency Call
          </a>

          <button
            type="button"
            className={`flex h-10 w-10 items-center justify-center rounded-xl transition-colors lg:hidden ${
              isScrolled
                ? "text-slate-700 hover:bg-slate-100"
                : "text-white hover:bg-white/10"
            }`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-expanded={isMobileMenuOpen}
            aria-controls="mobile-menu"
            aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMobileMenuOpen ? (
              <X className="h-5 w-5" aria-hidden="true" />
            ) : (
              <Menu className="h-5 w-5" aria-hidden="true" />
            )}
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div
        id="mobile-menu"
        className={`fixed inset-0 top-0 z-40 bg-white transition-transform duration-300 lg:hidden ${
          isMobileMenuOpen ? "translate-x-0" : "translate-x-full"
        }`}
        role="dialog"
        aria-modal="true"
        aria-label="Mobile navigation menu"
      >
        <div className="flex items-center justify-between px-4 py-3 sm:px-6">
          <Link
            href="/"
            className="flex items-center gap-2.5"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-600 text-white">
              <Brain className="h-5 w-5" aria-hidden="true" />
            </div>
            <span className="text-lg font-bold text-primary-900">
              Alemi Hospital
            </span>
          </Link>
          <button
            type="button"
            className="flex h-10 w-10 items-center justify-center rounded-xl text-slate-700 hover:bg-slate-100"
            onClick={() => setIsMobileMenuOpen(false)}
            aria-label="Close menu"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <nav className="mt-4 flex flex-col gap-1 px-4" aria-label="Mobile navigation">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-xl px-4 py-3 text-base font-medium transition-colors ${
                isActiveLink(link.href)
                  ? "bg-primary-50 text-primary-700"
                  : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
              }`}
              onClick={() => setIsMobileMenuOpen(false)}
              aria-current={isActiveLink(link.href) ? "page" : undefined}
            >
              {link.label}
            </Link>
          ))}

          <div className="mt-6 border-t border-slate-100 pt-6">
            <a
              href={`tel:${SITE_CONFIG.phone.replace(/\s/g, "")}`}
              className="flex items-center justify-center gap-2 rounded-xl bg-primary-600 px-4 py-3 text-base font-semibold text-white hover:bg-primary-700"
            >
              <Phone className="h-5 w-5" aria-hidden="true" />
              Emergency Call
            </a>
            <p className="mt-3 text-center text-sm text-slate-500">
              Available 24/7 for emergencies
            </p>
          </div>
        </nav>
      </div>
    </header>
  );
}
