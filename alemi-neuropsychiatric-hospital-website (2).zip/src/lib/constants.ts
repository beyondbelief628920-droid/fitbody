/**
 * Centralized constants for the Alemi Neuropsychiatric Hospital website.
 * All content, navigation, and configuration values are defined here
 * for easy maintenance and updates.
 */

export const SITE_CONFIG = {
  name: "Alemi Neuropsychiatric Hospital",
  shortName: "Alemi Hospital",
  tagline: "Healing Minds, Restoring Hope",
  description:
    "Afghanistan's first private neuropsychiatric hospital, providing compassionate mental health care since 2004 in Mazar-i-Sharif.",
  url: "https://alemihospital.org",
  phone: "+93 79 000 0000",
  email: "info@alemihospital.org",
  address: "Mazar-i-Sharif, Balkh Province, Afghanistan",
  foundedYear: 2004,
} as const;

export const NAV_LINKS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/services", label: "Services" },
  { href: "/contact", label: "Contact" },
] as const;

export const SERVICES = [
  {
    id: "outpatient",
    title: "Outpatient Psychiatry",
    description:
      "Comprehensive psychiatric consultations for 80–120 patients daily, providing expert diagnosis and personalized treatment plans.",
    icon: "Stethoscope" as const,
    features: [
      "Expert psychiatric evaluation",
      "Personalized treatment plans",
      "Medication management",
      "Follow-up consultations",
    ],
  },
  {
    id: "inpatient",
    title: "Inpatient Care",
    description:
      "Dedicated inpatient rooms for observation and intensive treatment, accommodating up to 20 patients across two floors.",
    icon: "BedDouble" as const,
    features: [
      "24-hour medical supervision",
      "Comfortable private rooms",
      "Crisis stabilization",
      "Integrated care plans",
    ],
  },
  {
    id: "counseling",
    title: "Psychological Counseling",
    description:
      "Individual and group counseling sessions addressing depression, anxiety, trauma, and other mental health challenges.",
    icon: "MessageCircle" as const,
    features: [
      "Individual therapy sessions",
      "Family counseling",
      "Trauma-focused therapy",
      "Stress management",
    ],
  },
  {
    id: "diagnostic",
    title: "Diagnostic Services",
    description:
      "Advanced diagnostic capabilities including ECG and X-ray to rule out underlying physical causes of mental health symptoms.",
    icon: "Activity" as const,
    features: [
      "ECG testing",
      "X-ray diagnostics",
      "Laboratory services",
      "Comprehensive assessments",
    ],
  },
  {
    id: "pharmacological",
    title: "Pharmacological Treatment",
    description:
      "Evidence-based medication management with affordable generic medications imported from trusted international sources.",
    icon: "Pill" as const,
    features: [
      "Affordable medications",
      "Prescription management",
      "Drug interaction reviews",
      "Ongoing medication monitoring",
    ],
  },
  {
    id: "telemedicine",
    title: "Remote Follow-Up",
    description:
      "Telephone-based follow-up consultations for patients traveling long distances, ensuring continuity of care between visits.",
    icon: "PhoneCall" as const,
    features: [
      "Phone consultations",
      "Medication adjustments",
      "Progress monitoring",
      "Emergency guidance",
    ],
  },
] as const;

export const CONDITIONS_TREATED = [
  {
    name: "Depression",
    description:
      "Major depressive disorder affecting daily functioning, energy, and well-being.",
    prevalence: "68% of Afghans affected",
  },
  {
    name: "Anxiety Disorders",
    description:
      "Persistent worry, fear, and physical symptoms of anxiety impacting quality of life.",
    prevalence: "72% of Afghans affected",
  },
  {
    name: "PTSD",
    description:
      "Trauma-related symptoms from decades of conflict, including flashbacks and hypervigilance.",
    prevalence: "42–66% estimated",
  },
  {
    name: "Schizophrenia",
    description:
      "Complex psychiatric condition requiring long-term management and medication support.",
    prevalence: "Commonly treated",
  },
  {
    name: "Bipolar Disorder",
    description:
      "Mood disorders involving episodes of mania and depression requiring specialized care.",
    prevalence: "Commonly treated",
  },
  {
    name: "Drug-Induced Psychosis",
    description:
      "Substance-related psychiatric conditions requiring integrated treatment approaches.",
    prevalence: "Commonly treated",
  },
] as const;

export const STATS = [
  { value: 2004, label: "Year Founded", suffix: "" },
  { value: 20000, label: "Patients Treated", suffix: "+" },
  { value: 120, label: "Daily Outpatients", suffix: "+" },
  { value: 20, label: "Inpatient Beds", suffix: "" },
  { value: 964, label: "Provinces Reached", suffix: "+" },
  { value: 20, label: "Years of Service", suffix: "+" },
] as const;

export const TEAM_MEMBERS = [
  {
    name: "Dr. Mohammad Nader Alemi",
    role: "Founder & Director (2004–2021)",
    description:
      "Afghanistan's pioneering psychiatrist, Dr. Alemi founded the country's first private neuropsychiatric hospital in 2004. A graduate of Kabul Medical Institution, he dedicated his life to serving those suffering from mental illness, treating all patients with equal compassion regardless of background. His legacy of selfless service continues to inspire every aspect of our hospital's mission.",
    isFounder: true,
  },
  {
    name: "Dr. Fardeen Alemi",
    role: "Medical Director",
    description:
      "Continuing his father's legacy, Dr. Fardeen Alemi leads the hospital's clinical operations with the same dedication to compassionate, accessible psychiatric care for all Afghans.",
    isFounder: false,
  },
  {
    name: "Dr. Khan Murad Muradi",
    role: "Senior Psychiatrist",
    description:
      "A long-standing member of the Alemi Hospital team, Dr. Muradi provides expert psychiatric care and has been instrumental in maintaining the hospital's mission through challenging times.",
    isFounder: false,
  },
  {
    name: "Parvin Alemi",
    role: "Community Education Director",
    description:
      "A champion of education and women's empowerment, Parvin Alemi famously ran an underground school for 100 girls during the Taliban era. She now leads community mental health awareness programs.",
    isFounder: false,
  },
] as const;

export const TESTIMONIALS = [
  {
    quote:
      "I traveled 700 kilometers to see Dr. Alemi. He was the only doctor who truly understood my suffering. After years of depression, I finally have hope again.",
    author: "Patient from Kunduz",
    role: "Outpatient",
  },
  {
    quote:
      "My family thought I was possessed. Dr. Alemi explained it was depression and treated me with dignity. The medication changed my life completely.",
    author: "Patient from Balkh",
    role: "Inpatient",
  },
  {
    quote:
      "The hospital staff treated my mother with such kindness. They never made us feel ashamed about her mental illness. We are forever grateful.",
    author: "Family Member",
    role: "Relative of Patient",
  },
  {
    quote:
      "After years of nightmares and fear, the counseling sessions at Alemi Hospital helped me find peace again. I can now sleep without medication.",
    author: "Patient from Samangan",
    role: "Outpatient",
  },
] as const;

export const TIMELINE_EVENTS = [
  {
    year: "1983",
    title: "Medical Education",
    description:
      "Dr. Nader Alemi graduates from Kabul Medical Institution with a Medical Doctorate, beginning his journey in medicine.",
  },
  {
    year: "1988",
    title: "Neuropsychiatric Specialization",
    description:
      "Dr. Alemi becomes Head and Specialist Trainer of the Neuropsychiatric Department at Mazar Civil Hospital, serving the northern region.",
  },
  {
    year: "1990s",
    title: "Treating Under Siege",
    description:
      "During Taliban rule, Dr. Alemi treats thousands of patients — including Taliban fighters — while his wife Parvin secretly educates 100 girls in an underground school.",
  },
  {
    year: "2004",
    title: "Hospital Founded",
    description:
      "Alemi Neuropsychiatric Hospital opens as Afghanistan's first private psychiatric facility, filling a critical gap in mental health care.",
  },
  {
    year: "2012",
    title: "National Recognition",
    description:
      "The hospital is recognized by the Society of Mental Health Specialists as a beacon of mental health treatment in Afghanistan.",
  },
  {
    year: "2016",
    title: "International Attention",
    description:
      "Featured by the BBC, The Guardian, and LSE, bringing global awareness to Afghanistan's mental health crisis and the hospital's vital work.",
  },
  {
    year: "2021",
    title: "Enduring Legacy",
    description:
      "Dr. Alemi's tragic passing marks the end of an era, but his family and dedicated staff continue his mission of compassionate care.",
  },
  {
    year: "Today",
    title: "Continuing the Mission",
    description:
      "Alemi Hospital continues serving thousands of patients annually, honoring Dr. Alemi's vision of accessible mental health care for all Afghans.",
  },
] as const;

export const WORKING_HOURS = [
  { day: "Saturday – Wednesday", hours: "8:00 AM – 8:00 PM" },
  { day: "Thursday", hours: "8:00 AM – 4:00 PM" },
  { day: "Friday", hours: "Emergency Only" },
] as const;
