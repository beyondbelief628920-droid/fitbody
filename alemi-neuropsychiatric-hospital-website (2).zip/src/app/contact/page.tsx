import type { Metadata } from "next";
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  Shield,
  Heart,
  AlertTriangle,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";
import { SectionHeading } from "@/components/SectionHeading";
import { ContactForm } from "@/components/ContactForm";
import { SITE_CONFIG, WORKING_HOURS } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Alemi Neuropsychiatric Hospital. Schedule an appointment, ask questions, or reach our emergency line. We're here to help.",
};

/* ---------- Hero Banner ---------- */
function ContactHero() {
  return (
    <section className="relative overflow-hidden bg-primary-900 pt-28 pb-20 sm:pt-36 sm:pb-28">
      <div className="absolute inset-0 hero-gradient pattern-dots opacity-90" />
      <div className="absolute top-20 left-20 h-64 w-64 rounded-full bg-warm-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-white/90 backdrop-blur-sm">
            Contact Us
          </span>
          <h1 className="mt-6 text-4xl font-extrabold text-white sm:text-5xl lg:text-6xl">
            We&apos;re Here to{" "}
            <span className="text-accent-300">Help</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">
            Whether you&apos;re seeking help for yourself or a loved one, our
            team is ready to assist. Reach out to us through any of the
            channels below or fill out our contact form.
          </p>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ---------- Contact Cards ---------- */
function ContactCards() {
  const cards = [
    {
      icon: Phone,
      title: "Phone",
      info: SITE_CONFIG.phone,
      detail: "Available for appointments & emergencies",
      href: `tel:${SITE_CONFIG.phone.replace(/\s/g, "")}`,
      cta: "Call Now",
    },
    {
      icon: Mail,
      title: "Email",
      info: SITE_CONFIG.email,
      detail: "We typically respond within 24 hours",
      href: `mailto:${SITE_CONFIG.email}`,
      cta: "Send Email",
    },
    {
      icon: MapPin,
      title: "Location",
      info: SITE_CONFIG.address,
      detail: "Four-story modern facility",
      href: undefined,
      cta: undefined,
    },
    {
      icon: Clock,
      title: "Working Hours",
      info: WORKING_HOURS[0].hours,
      detail: WORKING_HOURS.map((h) => `${h.day}: ${h.hours}`).join(" • "),
      href: undefined,
      cta: undefined,
    },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Get in Touch"
            title="Contact Information"
            subtitle="Multiple ways to reach us. Choose whatever is most comfortable for you."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((card, index) => (
            <AnimatedSection
              key={card.title}
              animation="fade-in-up"
              delay={index * 100}
            >
              <div className="h-full rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <card.icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-slate-900">
                  {card.title}
                </h3>
                <p className="mt-1 text-sm font-medium text-primary-600">
                  {card.info}
                </p>
                <p className="mt-1 text-xs text-slate-500">{card.detail}</p>
                {card.href && card.cta && (
                  <a
                    href={card.href}
                    className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-primary-600 transition-colors hover:text-primary-700"
                  >
                    {card.cta}
                    <span aria-hidden="true">→</span>
                  </a>
                )}
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Form & Map Section ---------- */
function FormSection() {
  return (
    <section className="bg-slate-50 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-5">
          {/* Form */}
          <div className="lg:col-span-3">
            <AnimatedSection animation="fade-in-left">
              <SectionHeading
                align="left"
                badge="Send a Message"
                title="How Can We Help?"
                subtitle="Fill out the form below and our team will get back to you as soon as possible. All information is kept strictly confidential."
              />
              <div className="mt-8">
                <ContactForm />
              </div>
            </AnimatedSection>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-2">
            <AnimatedSection animation="fade-in-right">
              {/* Emergency Card */}
              <div className="rounded-2xl border-2 border-red-200 bg-red-50 p-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-red-100 text-red-600">
                    <AlertTriangle className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <h3 className="text-lg font-bold text-red-900">
                    Mental Health Emergency?
                  </h3>
                </div>
                <p className="mt-3 text-sm text-red-700">
                  If you or someone you know is in immediate danger or
                  experiencing a mental health crisis, please call our
                  emergency line immediately.
                </p>
                <a
                  href={`tel:${SITE_CONFIG.phone.replace(/\s/g, "")}`}
                  className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-red-600 px-4 py-3 text-sm font-semibold text-white transition-colors hover:bg-red-700"
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  Emergency: {SITE_CONFIG.phone}
                </a>
              </div>

              {/* Confidentiality Card */}
              <div className="mt-6 rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                    <Shield className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">
                    Your Privacy Matters
                  </h3>
                </div>
                <p className="mt-3 text-sm text-slate-600">
                  All communications and medical records are kept strictly
                  confidential. We follow international medical privacy
                  standards to protect your personal information.
                </p>
              </div>

              {/* What to Expect Card */}
              <div className="mt-6 rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-accent-50 text-accent-600">
                    <Heart className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-900">
                    What to Expect
                  </h3>
                </div>
                <ul className="mt-3 space-y-2 text-sm text-slate-600">
                  <li className="flex items-start gap-2">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400" aria-hidden="true" />
                    A warm, non-judgmental environment
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400" aria-hidden="true" />
                    Professional psychiatric evaluation
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400" aria-hidden="true" />
                    Personalized treatment plan
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400" aria-hidden="true" />
                    Affordable, transparent pricing
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-1 h-1.5 w-1.5 shrink-0 rounded-full bg-accent-400" aria-hidden="true" />
                    Ongoing follow-up support
                  </li>
                </ul>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================
   Contact Page
   ============================================================ */
export default function ContactPage() {
  return (
    <>
      <ContactHero />
      <ContactCards />
      <FormSection />
    </>
  );
}
