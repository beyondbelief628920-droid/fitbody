import Link from "next/link";
import {
  Brain,
  Stethoscope,
  BedDouble,
  MessageCircle,
  Activity,
  Pill,
  PhoneCall,
  Phone,
  ArrowRight,
  Shield,
  Heart,
  Users,
  Quote,
  Star,
  Clock,
  CheckCircle2,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";
import { SectionHeading } from "@/components/SectionHeading";
import {
  SITE_CONFIG,
  STATS,
  SERVICES,
  TESTIMONIALS,
  CONDITIONS_TREATED,
} from "@/lib/constants";

/* ---------- Icon map for dynamic rendering ---------- */
const iconMap: Record<string, React.ComponentType<{ className?: string; "aria-hidden"?: boolean }>> = {
  Stethoscope,
  BedDouble,
  MessageCircle,
  Activity,
  Pill,
  PhoneCall,
};

/* ---------- Hero Section ---------- */
function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 hero-gradient pattern-dots" />
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItSDJ2LTJoMzR6bTAtMzBWMkgydjJoMzR6TTIgMjJoMzR2LTJIMnYyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-40" />

      {/* Decorative shapes */}
      <div className="absolute top-20 right-10 h-72 w-72 rounded-full bg-accent-500/10 blur-3xl" />
      <div className="absolute bottom-20 left-10 h-96 w-96 rounded-full bg-primary-400/10 blur-3xl" />

      <div className="relative z-10 mx-auto max-w-7xl px-4 py-32 sm:px-6 sm:py-40 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          {/* Text Content */}
          <div>
            <AnimatedSection animation="fade-in-down">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium text-white/90 backdrop-blur-sm">
                <Shield className="h-4 w-4 text-accent-400" aria-hidden="true" />
                Afghanistan&apos;s First Private Psychiatric Hospital
              </span>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={200}>
              <h1 className="mt-6 text-4xl font-extrabold leading-tight tracking-tight text-white sm:text-5xl lg:text-6xl">
                Healing Minds,{" "}
                <span className="text-accent-300">Restoring Hope</span>
              </h1>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={400}>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-white/80">
                Since 2004, Alemi Neuropsychiatric Hospital has been the
                beacon of mental health care in Afghanistan. Founded by
                Dr. Mohammad Nader Alemi, we provide compassionate,
                evidence-based treatment to thousands of patients each year.
              </p>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={600}>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link
                  href="/services"
                  className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-semibold text-primary-700 shadow-lg shadow-black/10 transition-all duration-200 hover:bg-primary-50 hover:shadow-xl"
                >
                  Our Services
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 rounded-xl border-2 border-white/30 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-200 hover:bg-white/20"
                >
                  <Phone className="h-4 w-4" aria-hidden="true" />
                  Book Appointment
                </Link>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-in-up" delay={800}>
              <div className="mt-10 flex items-center gap-6 text-white/60">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-accent-400" aria-hidden="true" />
                  <span className="text-sm">No Weapons Policy</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-accent-400" aria-hidden="true" />
                  <span className="text-sm">All Patients Welcome</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-4 w-4 text-accent-400" aria-hidden="true" />
                  <span className="text-sm">Affordable Care</span>
                </div>
              </div>
            </AnimatedSection>
          </div>

          {/* Stats Card */}
          <AnimatedSection animation="fade-in-right" delay={400}>
            <div className="glass rounded-3xl p-8 sm:p-10">
              <div className="grid grid-cols-2 gap-6">
                {STATS.slice(0, 4).map((stat) => (
                  <div key={stat.label} className="text-center">
                    <p className="text-3xl font-extrabold text-white sm:text-4xl">
                      {stat.value.toLocaleString()}
                      <span className="text-accent-300">{stat.suffix}</span>
                    </p>
                    <p className="mt-1 text-xs font-medium uppercase tracking-wider text-white/60">
                      {stat.label}
                    </p>
                  </div>
                ))}
              </div>
              <div className="mt-8 border-t border-white/10 pt-6">
                <p className="text-center text-sm text-white/60">
                  Serving patients from <strong className="text-white/80">all 34 provinces</strong> of Afghanistan
                </p>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2">
        <div className="flex flex-col items-center gap-2 text-white/40">
          <span className="text-xs uppercase tracking-widest">Scroll</span>
          <div className="h-10 w-6 rounded-full border-2 border-white/20 p-1">
            <div className="h-2 w-1.5 mx-auto rounded-full bg-white/50 animate-bounce" />
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Services Preview Section ---------- */
function ServicesPreviewSection() {
  return (
    <section className="relative py-20 sm:py-28 section-gradient" id="services-preview">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Our Services"
            title="Comprehensive Psychiatric Care"
            subtitle="From outpatient consultations to inpatient treatment, we provide a full spectrum of mental health services tailored to the needs of the Afghan people."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, index) => {
            const IconComp = iconMap[service.icon];
            return (
              <AnimatedSection
                key={service.id}
                animation="fade-in-up"
                delay={index * 100}
              >
                <div className="group relative h-full rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-xl hover:shadow-primary-100/40 hover:-translate-y-1">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600 transition-colors group-hover:bg-primary-600 group-hover:text-white">
                    {IconComp && <IconComp className="h-6 w-6" aria-hidden={true} />}
                  </div>
                  <h3 className="mt-4 text-lg font-bold text-slate-900">
                    {service.title}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">
                    {service.description}
                  </p>
                  <ul className="mt-4 space-y-1.5">
                    {service.features.slice(0, 3).map((feature) => (
                      <li
                        key={feature}
                        className="flex items-center gap-2 text-sm text-slate-500"
                      >
                        <CheckCircle2
                          className="h-3.5 w-3.5 shrink-0 text-accent-500"
                          aria-hidden="true"
                        />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </AnimatedSection>
            );
          })}
        </div>

        <AnimatedSection animation="fade-in-up" delay={600} className="mt-12 text-center">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 rounded-xl bg-primary-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-primary-600/25 transition-all duration-200 hover:bg-primary-700 hover:shadow-xl"
          >
            View All Services
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ---------- Conditions Treated Section ---------- */
function ConditionsSection() {
  return (
    <section className="bg-primary-950 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Conditions We Treat"
            title="Mental Health Conditions"
            subtitle="We treat a wide range of psychiatric and neurological conditions, providing hope and healing to those who need it most."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {CONDITIONS_TREATED.map((condition, index) => (
            <AnimatedSection
              key={condition.name}
              animation="scale-in"
              delay={index * 100}
            >
              <div className="group rounded-2xl border border-primary-800/50 bg-primary-900/50 p-6 transition-all duration-300 hover:bg-primary-800/60 hover:border-primary-700/50">
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-bold text-white">
                    {condition.name}
                  </h3>
                  <span className="shrink-0 rounded-full bg-accent-500/20 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-accent-300">
                    {condition.prevalence}
                  </span>
                </div>
                <p className="mt-2 text-sm leading-relaxed text-primary-200/70">
                  {condition.description}
                </p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- About Preview Section ---------- */
function AboutPreviewSection() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <AnimatedSection animation="fade-in-left">
            <div className="relative">
              {/* Decorative background */}
              <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-primary-100 to-accent-50 opacity-60" />
              <div className="relative rounded-2xl bg-white p-8 shadow-xl sm:p-10">
                <div className="flex items-center gap-3">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-600 text-white">
                    <Brain className="h-7 w-7" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-2xl font-extrabold text-primary-900">
                      Dr. Mohammad Nader Alemi
                    </p>
                    <p className="text-sm text-primary-600">
                      Founder & Director (2004–2021)
                    </p>
                  </div>
                </div>
                <blockquote className="mt-6 border-l-4 border-accent-400 pl-4">
                  <p className="text-base italic leading-relaxed text-slate-700">
                    &ldquo;I used to treat the Taliban as human beings, same as I
                    would treat my other patients… even though I knew they had
                    caused all the problems in our society. Sometimes, they would
                    weep and I would comfort them.&rdquo;
                  </p>
                  <cite className="mt-2 block text-sm text-slate-500 not-italic">
                    — Dr. Nader Alemi, BBC News
                  </cite>
                </blockquote>
                <div className="mt-6 grid grid-cols-3 gap-4">
                  <div className="rounded-xl bg-primary-50 p-3 text-center">
                    <p className="text-xl font-bold text-primary-700">1983</p>
                    <p className="text-[10px] uppercase tracking-wider text-primary-500">
                      MD Graduate
                    </p>
                  </div>
                  <div className="rounded-xl bg-accent-50 p-3 text-center">
                    <p className="text-xl font-bold text-accent-700">2004</p>
                    <p className="text-[10px] uppercase tracking-wider text-accent-500">
                      Hospital Founded
                    </p>
                  </div>
                  <div className="rounded-xl bg-warm-50 p-3 text-center">
                    <p className="text-xl font-bold text-warm-700">20K+</p>
                    <p className="text-[10px] uppercase tracking-wider text-warm-500">
                      Lives Touched
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </AnimatedSection>

          <AnimatedSection animation="fade-in-right">
            <SectionHeading
              align="left"
              badge="Our Story"
              title="A Legacy of Compassion & Courage"
            />
            <p className="mt-4 text-base leading-relaxed text-slate-600">
              In 2004, Dr. Mohammad Nader Alemi opened Afghanistan&apos;s first
              private neuropsychiatric hospital in Mazar-i-Sharif. As the only
              Pashto-speaking psychiatrist in the north, he treated thousands —
              from ordinary citizens to Taliban fighters — with equal compassion
              and dignity.
            </p>
            <p className="mt-4 text-base leading-relaxed text-slate-600">
              While treating patients under Taliban rule, his wife Parvin
              secretly ran an underground school for 100 girls. Their shared
              commitment to healing and education in the face of adversity
              defines the spirit of our hospital.
            </p>
            <p className="mt-4 text-base leading-relaxed text-slate-600">
              Today, Dr. Alemi&apos;s family and dedicated staff continue his
              mission, serving thousands of patients each year from all across
              Afghanistan.
            </p>
            <Link
              href="/about"
              className="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary-600 transition-colors hover:text-primary-700"
            >
              Read Our Full Story
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}

/* ---------- Testimonials Section ---------- */
function TestimonialsSection() {
  return (
    <section className="bg-slate-50 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Testimonials"
            title="Stories of Hope & Healing"
            subtitle="Every patient's journey is unique. Here are some voices from the thousands we've had the privilege to serve."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2">
          {TESTIMONIALS.map((testimonial, index) => (
            <AnimatedSection
              key={testimonial.author}
              animation="fade-in-up"
              delay={index * 150}
            >
              <div className="relative h-full rounded-2xl bg-white p-6 shadow-sm transition-shadow hover:shadow-lg sm:p-8">
                <Quote
                  className="absolute top-4 right-4 h-8 w-8 text-primary-100"
                  aria-hidden="true"
                />
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-warm-400 text-warm-400"
                      aria-hidden="true"
                    />
                  ))}
                </div>
                <p className="mt-4 text-base leading-relaxed text-slate-600 italic">
                  &ldquo;{testimonial.quote}&rdquo;
                </p>
                <div className="mt-6 flex items-center gap-3 border-t border-slate-100 pt-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-100 text-primary-600">
                    <Users className="h-5 w-5" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      {testimonial.author}
                    </p>
                    <p className="text-xs text-slate-500">
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Stats Banner Section ---------- */
function StatsBannerSection() {
  return (
    <section className="relative overflow-hidden bg-primary-700 py-16">
      <div className="absolute inset-0 pattern-dots opacity-30" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-6">
          {STATS.map((stat, index) => (
            <AnimatedSection
              key={stat.label}
              animation="fade-in-up"
              delay={index * 100}
              className="text-center"
            >
              <p className="text-3xl font-extrabold text-white sm:text-4xl">
                {stat.value.toLocaleString()}
                <span className="text-accent-300">{stat.suffix}</span>
              </p>
              <p className="mt-1 text-xs font-medium uppercase tracking-wider text-primary-200">
                {stat.label}
              </p>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- CTA Section ---------- */
function CTASection() {
  return (
    <section className="relative overflow-hidden py-20 sm:py-28">
      <div className="absolute inset-0 cta-gradient" />
      <div className="absolute inset-0 pattern-dots opacity-20" />
      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <AnimatedSection>
          <Heart className="mx-auto h-12 w-12 text-white/60" aria-hidden="true" />
          <h2 className="mt-6 text-3xl font-extrabold text-white sm:text-4xl lg:text-5xl">
            Take the First Step Toward Healing
          </h2>
          <p className="mt-4 text-lg text-white/80">
            Mental health is not a shame — it&apos;s a medical condition that
            deserves treatment. Our doors are open to everyone. Let us help you
            find your path to recovery.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-semibold text-primary-700 shadow-lg transition-all duration-200 hover:bg-primary-50 hover:shadow-xl"
            >
              <Phone className="h-4 w-4" aria-hidden="true" />
              Contact Us Today
            </Link>
            <Link
              href="/services"
              className="inline-flex items-center gap-2 rounded-xl border-2 border-white/30 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-200 hover:bg-white/20"
            >
              Explore Services
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap justify-center gap-6 text-sm text-white/60">
            <span className="flex items-center gap-2">
              <Clock className="h-4 w-4" aria-hidden="true" />
              Open 6 Days a Week
            </span>
            <span className="flex items-center gap-2">
              <Shield className="h-4 w-4" aria-hidden="true" />
              Confidential & Safe
            </span>
            <span className="flex items-center gap-2">
              <Heart className="h-4 w-4" aria-hidden="true" />
              Compassionate Care
            </span>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ============================================================
   Home Page
   ============================================================ */
export default function HomePage() {
  return (
    <>
      <HeroSection />
      <ServicesPreviewSection />
      <AboutPreviewSection />
      <ConditionsSection />
      <StatsBannerSection />
      <TestimonialsSection />
      <CTASection />
    </>
  );
}
