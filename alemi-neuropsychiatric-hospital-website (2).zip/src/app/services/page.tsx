import type { Metadata } from "next";
import Link from "next/link";
import {
  Stethoscope,
  BedDouble,
  MessageCircle,
  Activity,
  Pill,
  PhoneCall,
  Phone,
  ArrowRight,
  CheckCircle2,
  Clock,
  Shield,
  Heart,
  DollarSign,
  MapPin,
  Users,
  ChevronRight,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";
import { SectionHeading } from "@/components/SectionHeading";
import { SERVICES, CONDITIONS_TREATED, WORKING_HOURS } from "@/lib/constants";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Explore the comprehensive psychiatric services offered by Alemi Neuropsychiatric Hospital — from outpatient consultations and inpatient care to diagnostic services and remote follow-up.",
};

const iconMap: Record<string, React.ComponentType<{ className?: string; "aria-hidden"?: boolean }>> = {
  Stethoscope,
  BedDouble,
  MessageCircle,
  Activity,
  Pill,
  PhoneCall,
};

/* ---------- Hero Banner ---------- */
function ServicesHero() {
  return (
    <section className="relative overflow-hidden bg-primary-900 pt-28 pb-20 sm:pt-36 sm:pb-28">
      <div className="absolute inset-0 hero-gradient pattern-dots opacity-90" />
      <div className="absolute bottom-0 left-0 h-64 w-64 rounded-full bg-accent-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-white/90 backdrop-blur-sm">
            Our Services
          </span>
          <h1 className="mt-6 text-4xl font-extrabold text-white sm:text-5xl lg:text-6xl">
            Comprehensive{" "}
            <span className="text-accent-300">Psychiatric Care</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">
            From daily outpatient consultations to inpatient treatment and
            remote follow-up, we provide a full spectrum of mental health
            services designed for the Afghan people.
          </p>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ---------- Detailed Services ---------- */
function DetailedServicesSection() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="What We Offer"
            title="Our Services in Detail"
            subtitle="Each service is designed with the unique needs of our patients in mind, ensuring accessible and effective mental health care."
          />
        </AnimatedSection>

        <div className="mt-16 space-y-12">
          {SERVICES.map((service, index) => {
            const IconComp = iconMap[service.icon];
            const isEven = index % 2 === 0;

            return (
              <AnimatedSection
                key={service.id}
                animation={isEven ? "fade-in-left" : "fade-in-right"}
              >
                <div
                  className={`flex flex-col gap-8 rounded-3xl border border-slate-100 bg-white p-8 shadow-sm transition-all duration-300 hover:shadow-lg sm:p-10 lg:flex-row lg:items-center ${
                    !isEven ? "lg:flex-row-reverse" : ""
                  }`}
                >
                  {/* Icon & Info */}
                  <div className="flex-1">
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-50 text-primary-600">
                      {IconComp && <IconComp className="h-8 w-8" aria-hidden={true} />}
                    </div>
                    <h3 className="mt-4 text-2xl font-bold text-slate-900">
                      {service.title}
                    </h3>
                    <p className="mt-2 text-base leading-relaxed text-slate-600">
                      {service.description}
                    </p>
                  </div>

                  {/* Features List */}
                  <div className="flex-1">
                    <h4 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
                      Key Features
                    </h4>
                    <ul className="mt-3 space-y-3">
                      {service.features.map((feature) => (
                        <li
                          key={feature}
                          className="flex items-center gap-3 text-slate-700"
                        >
                          <CheckCircle2
                            className="h-5 w-5 shrink-0 text-accent-500"
                            aria-hidden="true"
                          />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </AnimatedSection>
            );
          })}
        </div>
      </div>
    </section>
  );
}

/* ---------- Conditions Treated ---------- */
function ConditionsSection() {
  return (
    <section className="bg-slate-50 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Conditions We Treat"
            title="Expert Treatment for Mental Health Conditions"
            subtitle="Our experienced psychiatric team provides specialized treatment for a wide range of mental health conditions."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {CONDITIONS_TREATED.map((condition, index) => (
            <AnimatedSection
              key={condition.name}
              animation="scale-in"
              delay={index * 100}
            >
              <div className="h-full rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900">
                    {condition.name}
                  </h3>
                  <span className="shrink-0 rounded-full bg-warm-100 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-warm-700">
                    {condition.prevalence}
                  </span>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-slate-600">
                  {condition.description}
                </p>
                <Link
                  href="/contact"
                  className="mt-4 inline-flex items-center gap-1 text-xs font-semibold text-primary-600 transition-colors hover:text-primary-700"
                >
                  Request Consultation
                  <ChevronRight className="h-3 w-3" aria-hidden="true" />
                </Link>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Practical Info Section ---------- */
function PracticalInfoSection() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Practical Information"
            title="Visiting Our Hospital"
            subtitle="We want to make your visit as smooth as possible. Here's everything you need to know."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[
            {
              icon: DollarSign,
              title: "Affordable Care",
              items: [
                "Consultations from $3",
                "ECG: $3.50",
                "X-ray: $4",
                "Inpatient: ~$23/night",
              ],
            },
            {
              icon: Clock,
              title: "Working Hours",
              items: WORKING_HOURS.map(
                (h) => `${h.day}: ${h.hours}`
              ),
            },
            {
              icon: MapPin,
              title: "Location",
              items: [
                "Mazar-i-Sharif",
                "Balkh Province",
                "Northern Afghanistan",
                "4-story modern facility",
              ],
            },
            {
              icon: Users,
              title: "Capacity",
              items: [
                "80–120 daily outpatients",
                "20 inpatient beds",
                "2 inpatient floors",
                "Patients from 34 provinces",
              ],
            },
          ].map((info, index) => (
            <AnimatedSection
              key={info.title}
              animation="fade-in-up"
              delay={index * 100}
            >
              <div className="h-full rounded-2xl border border-slate-100 bg-white p-6 shadow-sm">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <info.icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-slate-900">
                  {info.title}
                </h3>
                <ul className="mt-3 space-y-2">
                  {info.items.map((item) => (
                    <li
                      key={item}
                      className="flex items-center gap-2 text-sm text-slate-600"
                    >
                      <div
                        className="h-1 w-1 shrink-0 rounded-full bg-accent-400"
                        aria-hidden="true"
                      />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- CTA Section ---------- */
function ServicesCTA() {
  return (
    <section className="relative overflow-hidden cta-gradient py-20 sm:py-28">
      <div className="absolute inset-0 pattern-dots opacity-20" />
      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <AnimatedSection>
          <Heart className="mx-auto h-12 w-12 text-white/60" aria-hidden="true" />
          <h2 className="mt-6 text-3xl font-extrabold text-white sm:text-4xl">
            Ready to Begin Your Journey?
          </h2>
          <p className="mt-4 text-lg text-white/80">
            Whether you&apos;re seeking help for yourself or a loved one, our
            team is here to guide you every step of the way.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-sm font-semibold text-primary-700 shadow-lg transition-all duration-200 hover:bg-primary-50 hover:shadow-xl"
            >
              <Phone className="h-4 w-4" aria-hidden="true" />
              Schedule Appointment
            </Link>
            <a
              href={`tel:${"+93790000000"}`}
              className="inline-flex items-center gap-2 rounded-xl border-2 border-white/30 bg-white/10 px-6 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-200 hover:bg-white/20"
            >
              <Shield className="h-4 w-4" aria-hidden="true" />
              Emergency Line
            </a>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ============================================================
   Services Page
   ============================================================ */
export default function ServicesPage() {
  return (
    <>
      <ServicesHero />
      <DetailedServicesSection />
      <ConditionsSection />
      <PracticalInfoSection />
      <ServicesCTA />
    </>
  );
}
