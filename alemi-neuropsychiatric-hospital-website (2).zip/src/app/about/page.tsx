import type { Metadata } from "next";
import Link from "next/link";
import {
  Brain,
  Heart,
  Shield,
  Users,
  Award,
  BookOpen,
  ArrowRight,
  Quote,
  GraduationCap,
  Lightbulb,
  HandHeart,
} from "lucide-react";
import { AnimatedSection } from "@/components/AnimatedSection";
import { SectionHeading } from "@/components/SectionHeading";
import { SITE_CONFIG, TEAM_MEMBERS, TIMELINE_EVENTS } from "@/lib/constants";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Learn about the history, mission, and legacy of Alemi Neuropsychiatric Hospital — Afghanistan's first private psychiatric hospital, founded in 2004 by Dr. Mohammad Nader Alemi.",
};

/* ---------- Hero Banner ---------- */
function AboutHero() {
  return (
    <section className="relative overflow-hidden bg-primary-900 pt-28 pb-20 sm:pt-36 sm:pb-28">
      <div className="absolute inset-0 hero-gradient pattern-dots opacity-90" />
      <div className="absolute top-10 right-20 h-64 w-64 rounded-full bg-accent-500/10 blur-3xl" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-white/90 backdrop-blur-sm">
            About Us
          </span>
          <h1 className="mt-6 text-4xl font-extrabold text-white sm:text-5xl lg:text-6xl">
            A Legacy of <span className="text-accent-300">Compassion</span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/80">
            For over two decades, Alemi Neuropsychiatric Hospital has stood as a
            beacon of hope in Afghanistan&apos;s mental health landscape. Our
            story is one of courage, dedication, and an unwavering commitment
            to healing.
          </p>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ---------- Mission & Vision ---------- */
function MissionVisionSection() {
  const values = [
    {
      icon: Heart,
      title: "Compassionate Care",
      description:
        "We treat every patient with dignity, kindness, and respect — regardless of their background, beliefs, or ability to pay.",
    },
    {
      icon: Shield,
      title: "Safe & Inclusive",
      description:
        "Our hospital maintains a strict no-weapons policy. Our security personnel carry no arms, ensuring a peaceful, therapeutic environment.",
    },
    {
      icon: Users,
      title: "Accessible to All",
      description:
        "From consultations costing just a few dollars to remote follow-up calls, we ensure mental health care reaches those who need it most.",
    },
    {
      icon: Award,
      title: "Clinical Excellence",
      description:
        "As Afghanistan's first private psychiatric hospital, we set the standard for evidence-based psychiatric treatment in the country.",
    },
    {
      icon: BookOpen,
      title: "Education & Training",
      description:
        "We are committed to training the next generation of mental health professionals to address Afghanistan's critical shortage.",
    },
    {
      icon: HandHeart,
      title: "Community Impact",
      description:
        "Beyond the hospital walls, we work to reduce the stigma of mental illness and promote mental health awareness across Afghanistan.",
    },
  ];

  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Our Mission"
            title="Healing Minds, Restoring Hope"
            subtitle="Our mission is to provide accessible, compassionate, and evidence-based psychiatric care to all Afghans, regardless of their circumstances. We envision a future where mental health care is available, affordable, and free from stigma."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {values.map((value, index) => (
            <AnimatedSection
              key={value.title}
              animation="fade-in-up"
              delay={index * 100}
            >
              <div className="h-full rounded-2xl border border-slate-100 bg-white p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-600">
                  <value.icon className="h-6 w-6" aria-hidden="true" />
                </div>
                <h3 className="mt-4 text-lg font-bold text-slate-900">
                  {value.title}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-600">
                  {value.description}
                </p>
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Timeline Section ---------- */
function TimelineSection() {
  return (
    <section className="bg-slate-50 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Our Journey"
            title="A History of Dedication"
            subtitle="From a single doctor's vision to Afghanistan's leading psychiatric institution, our journey spans decades of service, sacrifice, and hope."
          />
        </AnimatedSection>

        <div className="relative mt-16">
          {/* Vertical line */}
          <div
            className="absolute left-4 top-0 bottom-0 hidden w-0.5 bg-primary-200 sm:left-1/2 sm:block sm:-translate-x-0.5"
            aria-hidden="true"
          />

          <div className="space-y-8 sm:space-y-12">
            {TIMELINE_EVENTS.map((event, index) => {
              const isLeft = index % 2 === 0;
              return (
                <AnimatedSection
                  key={event.year}
                  animation={isLeft ? "fade-in-left" : "fade-in-right"}
                  delay={index * 100}
                >
                  <div
                    className={`relative flex flex-col sm:flex-row ${
                      isLeft ? "sm:flex-row" : "sm:flex-row-reverse"
                    }`}
                  >
                    {/* Content */}
                    <div className="flex-1 sm:px-8">
                      <div
                        className={`rounded-2xl border border-slate-100 bg-white p-6 shadow-sm ${
                          isLeft ? "sm:text-right" : "sm:text-left"
                        }`}
                      >
                        <span className="inline-block rounded-full bg-primary-100 px-3 py-1 text-xs font-bold text-primary-700">
                          {event.year}
                        </span>
                        <h3 className="mt-2 text-lg font-bold text-slate-900">
                          {event.title}
                        </h3>
                        <p className="mt-2 text-sm leading-relaxed text-slate-600">
                          {event.description}
                        </p>
                      </div>
                    </div>

                    {/* Dot */}
                    <div className="absolute left-4 top-6 hidden h-4 w-4 -translate-x-1/2 rounded-full border-4 border-primary-500 bg-white sm:left-1/2 sm:block" />

                    {/* Spacer */}
                    <div className="flex-1 sm:px-8" />
                  </div>
                </AnimatedSection>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- Team Section ---------- */
function TeamSection() {
  return (
    <section className="py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <SectionHeading
            badge="Our Team"
            title="Dedicated Professionals"
            subtitle="The people behind Alemi Hospital share a common commitment: providing compassionate, accessible mental health care to every patient who walks through our doors."
          />
        </AnimatedSection>

        <div className="mt-16 grid gap-8 sm:grid-cols-2">
          {TEAM_MEMBERS.map((member, index) => (
            <AnimatedSection
              key={member.name}
              animation="fade-in-up"
              delay={index * 150}
            >
              <div
                className={`h-full rounded-2xl p-6 sm:p-8 transition-all duration-300 hover:shadow-lg ${
                  member.isFounder
                    ? "border-2 border-primary-200 bg-primary-50/50"
                    : "border border-slate-100 bg-white"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl ${
                      member.isFounder
                        ? "bg-primary-600 text-white"
                        : "bg-primary-100 text-primary-600"
                    }`}
                  >
                    {member.isFounder ? (
                      <GraduationCap className="h-7 w-7" aria-hidden="true" />
                    ) : (
                      <Users className="h-7 w-7" aria-hidden="true" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">
                      {member.name}
                    </h3>
                    <p
                      className={`text-sm font-medium ${
                        member.isFounder ? "text-primary-600" : "text-slate-500"
                      }`}
                    >
                      {member.role}
                    </p>
                  </div>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-slate-600">
                  {member.description}
                </p>
                {member.isFounder && (
                  <div className="mt-4 flex items-center gap-2 text-primary-600">
                    <Lightbulb className="h-4 w-4" aria-hidden="true" />
                    <span className="text-xs font-semibold uppercase tracking-wider">
                      Founding Visionary
                    </span>
                  </div>
                )}
              </div>
            </AnimatedSection>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ---------- Legacy Quote Section ---------- */
function LegacySection() {
  return (
    <section className="relative overflow-hidden bg-primary-950 py-20 sm:py-28">
      <div className="absolute inset-0 pattern-dots opacity-20" />
      <div className="relative mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
        <AnimatedSection>
          <Quote className="mx-auto h-12 w-12 text-primary-500/40" aria-hidden="true" />
          <blockquote className="mt-6 text-2xl font-medium leading-relaxed text-white sm:text-3xl lg:text-4xl">
            &ldquo;He has always held this idea that I have to serve the people,
            and that&apos;s why he never left his country.&rdquo;
          </blockquote>
          <cite className="mt-6 block text-base text-primary-300 not-italic">
            — Dr. Fardeen Alemi, speaking about his father
          </cite>
          <div className="mt-8">
            <Link
              href="/services"
              className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-6 py-3 text-sm font-semibold text-white backdrop-blur-sm transition-all duration-200 hover:bg-white/20"
            >
              Continue His Legacy — Explore Our Services
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </Link>
          </div>
        </AnimatedSection>
      </div>
    </section>
  );
}

/* ============================================================
   About Page
   ============================================================ */
export default function AboutPage() {
  return (
    <>
      <AboutHero />
      <MissionVisionSection />
      <TimelineSection />
      <TeamSection />
      <LegacySection />
    </>
  );
}
